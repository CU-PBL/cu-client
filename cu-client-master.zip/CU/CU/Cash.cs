﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CU
{
    public partial class Cash : Form
    {
        public Cash()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void CashRecipt_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Not_Use(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                CashRecipt.Enabled = false;
                CashRecipt.Clear();
            }

            else
                CashRecipt.Enabled = true;
        }
    }
}
