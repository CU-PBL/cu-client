﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

namespace CU
{
    public partial class Cash : Form
    {
        public Cash()
        {
            InitializeComponent();
            tb_Total.Text = Temp.sum + "";
            radioButton1.Checked = true;
        }

        private void Pay_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Not_Use(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                CashRecipt.Enabled = false;
                CashRecipt.Clear();
            }

            else
                CashRecipt.Enabled = true;

        }

        private void calc_Change(object sender, EventArgs e)
        {
            tb_change.Text = (Decimal.Parse(tb_Received.Text) - Decimal.Parse(tb_Total.Text)).ToString();
        }

    }
}
