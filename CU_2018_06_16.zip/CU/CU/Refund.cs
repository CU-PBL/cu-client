﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

namespace CU
{
    public partial class Refund : Form
    {
        private List<SellListData> sellList = null;

        public Refund()
        {
            InitializeComponent();

            Console.WriteLine("요청 보내는중...");
            var client = new RestClient($"http://106.10.42.112:8000/sell/list");
            var request = new RestRequest(Method.GET);
            var response = client.Execute(request);

            sellList = Cson<SellListData>.ArrParse(response.Content);

            var cnt = 0;

            sellList.ForEach(x =>
            {
                RefundView.Rows.Add();
                RefundView.Rows[cnt].Cells["Column1"].Value = x.cashRecipt;
                RefundView.Rows[cnt].Cells["Column2"].Value = x.paymentOption;
                RefundView.Rows[cnt].Cells["Column3"].Value = x.cardNumber;
                RefundView.Rows[cnt].Cells["Column4"].Value = x.date;
                RefundView.Rows[cnt].Cells["Column5"].Value = x.sum;

                ++cnt;
            });
        }

        private void detailBtn_Click(object sender, EventArgs e)
        {
            for (var i = 0; i < RefundView.Rows.Count; i++)
            {
                if (!RefundView.Rows[i].Selected) continue;

                Console.WriteLine();

                Console.WriteLine("요청 보내는중...");
                var client = new RestClient($"http://106.10.42.112:8000/sell/list/{sellList[i].hash}");
                var request = new RestRequest(Method.GET);
                var response = client.Execute(request);

                var detailList = Cson<SellDetailData>.ArrParse(response.Content);

                var cnt = 0;

                DetailView.Rows.Clear();

                detailList.ForEach(x =>
                {
                    DetailView.Rows.Add();
                    DetailView.Rows[cnt].Cells["id"].Value = x.id;
                    DetailView.Rows[cnt].Cells["name"].Value = x.name;
                    DetailView.Rows[cnt].Cells["num"].Value = x.stock;
                    ++cnt;
                });
            }
        }
    }
}