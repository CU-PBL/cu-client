﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CU
{
    class StockData
    {
        public string name;
        public string category;
        public int id;
        public string price;
        public string sub_category;
        public int stock;

    }
}
