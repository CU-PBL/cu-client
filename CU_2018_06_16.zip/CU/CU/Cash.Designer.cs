﻿namespace CU
{
    partial class Cash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_Pay = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CashRecipt = new System.Windows.Forms.TextBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.tb_Received = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_change = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_Pay
            // 
            this.bt_Pay.Location = new System.Drawing.Point(157, 151);
            this.bt_Pay.Name = "bt_Pay";
            this.bt_Pay.Size = new System.Drawing.Size(123, 72);
            this.bt_Pay.TabIndex = 0;
            this.bt_Pay.Text = "Pay";
            this.bt_Pay.UseVisualStyleBackColor = true;
            this.bt_Pay.Click += new System.EventHandler(this.Pay_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "CashRecipt";
            // 
            // CashRecipt
            // 
            this.CashRecipt.Location = new System.Drawing.Point(105, 99);
            this.CashRecipt.Name = "CashRecipt";
            this.CashRecipt.Size = new System.Drawing.Size(175, 21);
            this.CashRecipt.TabIndex = 3;
            // 
            // tb_Total
            // 
            this.tb_Total.Location = new System.Drawing.Point(104, 44);
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.ReadOnly = true;
            this.tb_Total.Size = new System.Drawing.Size(175, 21);
            this.tb_Total.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "Total_Price";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(130, 128);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(45, 16);
            this.radioButton1.TabIndex = 10;
            this.radioButton1.Text = "Use";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(194, 128);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(68, 16);
            this.radioButton2.TabIndex = 11;
            this.radioButton2.Text = "Not Use";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.Not_Use);
            // 
            // tb_Received
            // 
            this.tb_Received.Location = new System.Drawing.Point(104, 15);
            this.tb_Received.Name = "tb_Received";
            this.tb_Received.Size = new System.Drawing.Size(175, 21);
            this.tb_Received.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "Received Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 76);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(49, 12);
            this.label4.TabIndex = 15;
            this.label4.Text = "Change";
            // 
            // tb_change
            // 
            this.tb_change.Location = new System.Drawing.Point(105, 72);
            this.tb_change.Name = "tb_change";
            this.tb_change.Size = new System.Drawing.Size(175, 21);
            this.tb_change.TabIndex = 14;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(28, 151);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 72);
            this.button2.TabIndex = 16;
            this.button2.Text = "calc";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.calc_Change);
            // 
            // Cash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 232);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_change);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_Received);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_Total);
            this.Controls.Add(this.CashRecipt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_Pay);
            this.Name = "Cash";
            this.Text = "Cash";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_Pay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CashRecipt;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox tb_Received;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_change;
        private System.Windows.Forms.Button button2;
    }
}