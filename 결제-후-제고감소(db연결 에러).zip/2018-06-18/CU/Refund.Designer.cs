﻿namespace CU
{
    partial class Refund
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RefundView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.detailBtn = new System.Windows.Forms.Button();
            this.DetailView = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.refundBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.RefundView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DetailView)).BeginInit();
            this.SuspendLayout();
            // 
            // RefundView
            // 
            this.RefundView.AllowUserToAddRows = false;
            this.RefundView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RefundView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.RefundView.Location = new System.Drawing.Point(11, 12);
            this.RefundView.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RefundView.Name = "RefundView";
            this.RefundView.RowTemplate.Height = 23;
            this.RefundView.Size = new System.Drawing.Size(775, 468);
            this.RefundView.TabIndex = 3;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "cashRecipt";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "paymentOption";
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "cardNumber";
            this.Column3.Name = "Column3";
            this.Column3.Width = 140;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "date";
            this.Column4.Name = "Column4";
            this.Column4.Width = 140;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "sum";
            this.Column5.Name = "Column5";
            this.Column5.Width = 110;
            // 
            // detailBtn
            // 
            this.detailBtn.Location = new System.Drawing.Point(793, 12);
            this.detailBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.detailBtn.Name = "detailBtn";
            this.detailBtn.Size = new System.Drawing.Size(282, 62);
            this.detailBtn.TabIndex = 4;
            this.detailBtn.Text = "Detail";
            this.detailBtn.UseVisualStyleBackColor = true;
            this.detailBtn.Click += new System.EventHandler(this.detailBtn_Click);
            // 
            // DetailView
            // 
            this.DetailView.AllowUserToAddRows = false;
            this.DetailView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DetailView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.name,
            this.num});
            this.DetailView.Location = new System.Drawing.Point(793, 82);
            this.DetailView.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DetailView.Name = "DetailView";
            this.DetailView.RowTemplate.Height = 23;
            this.DetailView.Size = new System.Drawing.Size(570, 398);
            this.DetailView.TabIndex = 5;
            // 
            // id
            // 
            this.id.HeaderText = "id";
            this.id.Name = "id";
            // 
            // name
            // 
            this.name.HeaderText = "name";
            this.name.Name = "name";
            this.name.Width = 300;
            // 
            // num
            // 
            this.num.HeaderText = "num";
            this.num.Name = "num";
            this.num.Width = 60;
            // 
            // refundBtn
            // 
            this.refundBtn.Location = new System.Drawing.Point(1081, 11);
            this.refundBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.refundBtn.Name = "refundBtn";
            this.refundBtn.Size = new System.Drawing.Size(282, 62);
            this.refundBtn.TabIndex = 6;
            this.refundBtn.Text = "Refund";
            this.refundBtn.UseVisualStyleBackColor = true;
            this.refundBtn.Click += new System.EventHandler(this.refundBtn_Click);
            // 
            // Refund
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1490, 498);
            this.Controls.Add(this.refundBtn);
            this.Controls.Add(this.DetailView);
            this.Controls.Add(this.detailBtn);
            this.Controls.Add(this.RefundView);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Refund";
            this.Text = "Refund";
            ((System.ComponentModel.ISupportInitialize)(this.RefundView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DetailView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView RefundView;
        private System.Windows.Forms.Button detailBtn;
        private System.Windows.Forms.DataGridView DetailView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn num;
        private System.Windows.Forms.Button refundBtn;
    }
}