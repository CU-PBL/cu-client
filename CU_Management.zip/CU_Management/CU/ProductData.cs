﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CU
{
    class ProductData
    {
        public string name, category, sub_category;
        public int id, price;
    }
}
