﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CU
{
    class ConstantData
    {
        public static string SERVER = "http://106.10.42.112:8000";
    }
}
