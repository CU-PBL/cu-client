﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

namespace CU
{
    public partial class Sale : Form
    {
        static List<StockData> productList;
        internal static object DataGridView1;

        public Sale()
        {

            InitializeComponent();
            
            var client = new RestClient($"http://106.10.42.112:8000/stock/list");
            var request = new RestRequest(Method.GET);
            var response = client.Execute(request);

            productList = Cson<StockData>.ArrParse(response.Content);
        }

        private void Pay(object sender, EventArgs e)
        {
            Temp.sum = int.Parse(textBox3.Text);

            Console.WriteLine(Temp.sum);

            for(int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                Temp.id[i] = (int)dataGridView1.Rows[i].Cells["Column1"].Value;
                Temp.stock[i] = (int)dataGridView1.Rows[i].Cells["Column4"].Value;
            }

            paymentoption pay = new paymentoption();
            pay.Show();
            this.Hide();
        }

        private void Input_Click(object sender, EventArgs e)
        {
            int sum = 0;
            var text = int.Parse(textBox1.Text);
            int[] data = new int[100];
            if (text < 1 || text > 100)
                MessageBox.Show("없는 제품 번호입니다.");
            else
            {
                data[text - 1] += 1;

                for (int i = 0; i < 100; i++)
                {
                    if (data[i] != 0)
                    {
                        var client = new RestClient("http://106.10.42.112:8000/product/" + (i + 1));
                        var request = new RestRequest(Method.GET);
                        var response = client.Execute(request);
                        var result = Cson<ProductData>.DeParse(response.Content);

                        int setting = 0;
                        int set = 0;
                        for (int j = 0; j < dataGridView1.Rows.Count; j++)
                        {
                            if ((int)dataGridView1.Rows[j].Cells["Column1"].Value == result.id)
                            {
                                setting = 1;
                                set = j;
                            }
                        }

                        if (setting == 1)
                        {
                            foreach (var item in productList)
                            {
                                if (result.id ==item.id)
                                {
                                    int g = (int)dataGridView1.Rows[set].Cells["Column4"].Value;
                                    if (item.stock == g)
                                    {
                                        MessageBox.Show("더이상 재고가 없습니다.");
                                    }
                                    else
                                    {
                                        dataGridView1.Rows[set].Cells["Column4"].Value = g + 1;
                                        dataGridView1.Rows[set].Cells["Column5"].Value = result.price * (g + 1);
                                    }
                                    
                                }
                            } 
                           
                            
                        }
                        else
                        {
                            foreach (var item in productList)
                            {
                                if (result.id == item.id)
                                {
                                    if (item.stock <= 0)
                                    {
                                        MessageBox.Show("더이상 재고가 없습니다.");
                                    }
                                    else
                                    {
                                        var index = dataGridView1.Rows.Add();
                                        dataGridView1.Rows[index].Cells["Column1"].Value = result.id;
                                        dataGridView1.Rows[index].Cells["Column2"].Value = result.name;
                                        dataGridView1.Rows[index].Cells["Column3"].Value = result.price;
                                        dataGridView1.Rows[index].Cells["Column4"].Value = 1;
                                        dataGridView1.Rows[index].Cells["Column5"].Value = result.price;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            for (int j = 0; j < dataGridView1.Rows.Count; j++)
            {
                sum += (int)dataGridView1.Rows[j].Cells["Column5"].Value;
            }

            textBox3.Text = "" + sum;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            for (int i = 0; i<dataGridView1.Rows.Count; i++)
            {
                if(dataGridView1.Rows[i].Selected == true)
                {
                    if((int)dataGridView1.Rows[i].Cells["Column4"].Value==1)
                        dataGridView1.Rows.Remove(dataGridView1.Rows[i]);
                    else
                    {
                        int g = (int)dataGridView1.Rows[i].Cells["Column4"].Value;
                        int k = (int)dataGridView1.Rows[i].Cells["Column3"].Value;
                        dataGridView1.Rows[i].Cells["Column4"].Value = g - 1;
                        dataGridView1.Rows[i].Cells["Column5"].Value = k * (g - 1);
                    }
                }
            }
            int sum = 0;

            for (int j = 0; j < dataGridView1.Rows.Count; j++)
            {
                sum += (int)dataGridView1.Rows[j].Cells["Column5"].Value;
            }

            textBox3.Text = "" + sum;
        }

       
    }
}
