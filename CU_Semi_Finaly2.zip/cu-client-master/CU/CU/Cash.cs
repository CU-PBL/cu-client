﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

namespace CU
{
    public partial class Cash : Form
    {
        public Cash()
        {
            InitializeComponent();
            textBox2.Text = Temp.sum + "";
        }

        private void button1_Click(object sender, EventArgs e)
        {

            var data = new SellData
            {
                paymentOption = "cash",
                cardNumber = 0,
                cashRecipt = CashRecipt.Text,
                sum = Temp.sum
            };

            var sellData = Cson<SellData>.Parse(data);

            var client = new RestClient("http://106.10.42.112:8000/sell");
            var request = new RestRequest(Method.POST);
            request.AddHeader("content-type", "application/json");
            request.AddParameter("application/json", sellData, ParameterType.RequestBody);
            var response = client.Execute(request);
            Console.WriteLine(response.Content);

            this.Hide();
        }

   

        private void CashRecipt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Not_Use(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                CashRecipt.Enabled = false;
                CashRecipt.Clear();
            }

            else
                CashRecipt.Enabled = true;

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
