﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

namespace CU
{
    public partial class Cash : Form
    {
        public Cash()
        {
            InitializeComponent();
            tb_Total.Text = Temp.sum + "";
            radioButton1.Checked = true;
        }

        private void Pay_Click(object sender, EventArgs e)
        {

            if (radioButton1.Checked)
            {
                if (CashRecipt.Text == "")
                {
                    MessageBox.Show("현금영수증 번호를 입력하세요.");
                }
                else
                {
                    


                    var data = new SellData
                    {
                        paymentOption = "cash",
                        cardNumber = 0,
                        cashRecipt = CashRecipt.Text,
                        sum = Temp.sum
                    };

                    var sellData = Cson<SellData>.Parse(data);

                    var client = new RestClient("http://106.10.42.112:8000/sell");
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("content-type", "application/json");
                    request.AddParameter("application/json", sellData, ParameterType.RequestBody);
                    var response = client.Execute(request);
                    Console.WriteLine(response.Content);

                    Sale sale = new Sale();
                    sale.Show();
                    this.Hide();
                    MessageBox.Show("판매가 완료되었습니다.");
                }
            }
            else
            {
                var data = new SellData
                {
                    paymentOption = "cash",
                    cardNumber = 0,
                    cashRecipt = CashRecipt.Text,
                    sum = Temp.sum
                };

                var sellData = Cson<SellData>.Parse(data);

                var client = new RestClient("http://106.10.42.112:8000/sell");
                var request = new RestRequest(Method.POST);
                request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", sellData, ParameterType.RequestBody);
                var response = client.Execute(request);
                Console.WriteLine(response.Content);

                Sale sale = new Sale();
                sale.Show();
                this.Hide();
                MessageBox.Show("판매가 완료되었습니다.");
            }
        }

        private void Not_Use(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                CashRecipt.Enabled = false;
                CashRecipt.Clear();
            }

            else
                CashRecipt.Enabled = true;

        }

        private void calc_Change(object sender, EventArgs e)
        {
            tb_change.Text = (Decimal.Parse(tb_Received.Text) - Decimal.Parse(tb_Total.Text)).ToString();
        }

        private void CashRecipt_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
