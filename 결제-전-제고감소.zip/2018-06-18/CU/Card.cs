﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

namespace CU
{
    public partial class Card : Form
    {
        public Card()
        {
            InitializeComponent();
            textBox1.Text = Temp.sum + "";
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox2.Text != "")
            {
                


                var data = new SellData
                {
                    paymentOption = "card",
                    cardNumber = int.Parse(textBox2.Text),
                    cashRecipt = "",
                    sum = Temp.sum
                };

                var sellData = Cson<SellData>.Parse(data);

                var client = new RestClient("http://106.10.42.112:8000/sell");
                var request = new RestRequest(Method.POST);
                request.AddHeader("content-type", "application/json");
                request.AddParameter("application/json", sellData, ParameterType.RequestBody);
                var response = client.Execute(request);
                Console.WriteLine(response.Content);

                Sale sale = new Sale();
                sale.Show();
                this.Hide();
                MessageBox.Show("판매가 완료되었습니다.");
                
            }
            else
            {
                MessageBox.Show("카드번호를 입력하세요.");
            }
        }

        private void Card_Load(object sender, EventArgs e)
        {

        }

       
    }
}
